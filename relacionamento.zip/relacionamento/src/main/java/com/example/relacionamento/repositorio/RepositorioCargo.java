package com.example.relacionamento.repositorio;

import com.example.relacionamento.modelo.Cargo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioCargo extends JpaRepository<Cargo, Long> {
}
