package com.example.relacionamento.controller;
import com.example.relacionamento.modelo.Cargo;
import com.example.relacionamento.repositorio.RepositorioCargo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cargo")


public class ControleCargo {
    @Autowired
    private RepositorioCargo repositorioCargo;
    @GetMapping("/listar")
    public Iterable<Cargo>Listar(){
        return repositorioCargo.findAll();
    }

    @PostMapping("/cadastrar")
    public Cargo cadastrar(@RequestBody Cargo cargo){
        return repositorioCargo.save(cargo);
    }
}

