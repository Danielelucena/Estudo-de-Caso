package com.example.relacionamento.modelo;public class Colaborador {
}
